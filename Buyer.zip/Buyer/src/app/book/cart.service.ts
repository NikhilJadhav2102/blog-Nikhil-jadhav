import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  url = 'http://localhost:5000/cart'
  constructor(
    private router: Router,
    private httpClient: HttpClient
  ) { }
  addCartItem(bookId, price, quantity) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };

    const body = {
      bookId: bookId,
      price: price,
      quantity: quantity
    }
    console.log(body)
    return this.httpClient.post(this.url + '/addToCart', body, httpOptions)
  }
  getCartItems() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };

    return this.httpClient.get(this.url + '/getCart', httpOptions)
  }

  updateCartItem(cartId, quantity, price) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };

    const body = {
      cartId: cartId,
      price: price,
      quantity: quantity
    }

    return this.httpClient.put(this.url + '/' + cartId, body, httpOptions)
  }
  deleteCartItem(cartId) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };

    return this.httpClient.delete(this.url + '/' + cartId, httpOptions)
  }

  placeOrder() {
    // send the token along with the request
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    }
    const body = {

    }

    return this.httpClient.post('http://localhost:5000/order/', body, httpOptions)
  }
}

