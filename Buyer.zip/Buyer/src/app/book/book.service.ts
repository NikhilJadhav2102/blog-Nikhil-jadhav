import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  url = 'http://localhost:5000/book'


  constructor(
    private httpClient: HttpClient) { }


  getBooks() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    console.log(sessionStorage['token'])
    console.log(this.url + "/listBook")

    return this.httpClient.get(this.url + "/listBook", httpOptions)
  }
  // getProductInfo(bookId: number) {
  //   // send the token along with the request
  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       token: sessionStorage['token']
  //     })
  //   }

  //   return this.http.get(this.url + "/listBook/" + bookId, httpOptions)
  // }
  filterProducts(categoryId: number) {

    // send the token along with the request
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    }

    const body = {
      categoryId: categoryId,
    }

    return this.httpClient.post(this.url + "/searchByCategory", body, httpOptions)
  }
}
