import { CartComponent } from './../cart/cart.component';
import { ToastrService } from 'ngx-toastr';
import { CartService } from './../cart.service';
import { CategoryService } from './../category.service';
import { BookService } from './../book.service';
import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  books = []
  allBooks = []
  categories = []
  category = 0

  constructor(
    private bookService: BookService,
    private categoryService: CategoryService,
    private cartService: CartService,
    private toastr: ToastrService,
    private modalService: NgbModal,
  ) { }

  ngOnInit(): void {
    this.loadBook()
  }
  loadBook() {
    console.log("Inside bookload")
    this.bookService
      .getBooks()
      .subscribe(response => {
        console.log(response)
        if (response['status'] == 'success') {
          // this.allBooks = 
          this.allBooks = response['data']
          this.books = this.allBooks

        } else {
          alert(response['error'])
        }
      })
  }

  loadCategories() {
    this.categoryService
      .getCategories()
      .subscribe(response => {
        if (response['status'] == 'success') {
          this.categories = response['data']
          this.categories.push({ id: -1, title: 'All Categories' })
          console.log(this.categories)
        }
      })
  }
  addToCart(book) {
    console.log("inside add to cart")
    console.log(book)
    this.cartService
      .addCartItem(book['bookId'], book['price'], 1)
      .subscribe(response => {

        if (response['status'] == 'success') {
          console.log("inside add to cart sub")
          console.log(book['bookId'])
          this.toastr.success('added your product to cart')
        }
        else (response['status'] == 'error')
        {
          console.log(response['error'])
        }
      })
  }

  loadCart() {
    this.modalService.open(CartComponent, { size: 'lg' })
  }
  filterProducts() {
    this.bookService
      .filterProducts(this.category)
      .subscribe(response => {
        console.log(response)
        if (response['status'] == 'success') {
          this.books = response['data']
        } else {
          this.toastr.error(response['error'])
        }
      })
  }
}
