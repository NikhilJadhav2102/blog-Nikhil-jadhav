import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRoutingModule } from './user-routing.module';
import { AddAddressComponent } from './add-address/add-address.component';
import { ProfileComponent } from './profile/profile.component';
import { EditUserComponent } from './edit-user/edit-user.component';



@NgModule({
  declarations: [AddAddressComponent, ProfileComponent, EditUserComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    NgbModule,
    FormsModule
  ]
})
export class UserModule { }
