import { PathLocationStrategy } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url = 'http://localhost:5000/buyer'
  constructor(
    private httpClient: HttpClient) { }


  getUser() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    console.log(sessionStorage['token'])


    return this.httpClient.get(this.url, httpOptions)
  }
  updateBuyer(firstName, lastName, phone, email, address, city, state, country, zip) {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    const body = {

      "firstName": firstName,
      "lastName": lastName,
      "phone": phone,
      "email": email,
      "address": address,
      "city": city,
      "state": state,
      "country": country,
      "zip": zip

    }


    return this.httpClient.put(this.url + '/updateBuyer', body, httpOptions)
  }
}
