import { EditUserComponent } from './edit-user/edit-user.component';

import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAddressComponent } from './add-address/add-address.component';
import { ProfileComponent } from './profile/profile.component';


const routes: Routes = [

  { path: 'profile', component: ProfileComponent },
  { path: 'addAddress', component: AddAddressComponent },
  { path: 'edituser', component: EditUserComponent },


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
