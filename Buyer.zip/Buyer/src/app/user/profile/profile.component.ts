import { ToastrService } from 'ngx-toastr';
import { UserService } from './../user.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  buyers = []

  constructor(
    private userService: UserService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.loadProfile()

  }

  loadProfile() {
    console.log("Inside bookload")
    this.userService
      .getUser()
      .subscribe(response => {
        console.log(response)
        if (response['status'] == 'success') {
          // this.allBooks = 
          console.log(response['data'])
          this.buyers = response['data']

        } else {
          alert(response['error'])
        }
      })
  }
}
