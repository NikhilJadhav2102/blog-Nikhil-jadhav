import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from './../user.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  buyers = []

  firstName = ''
  lastName = ''
  phone = ''
  email = ''
  address = ''
  city = ''
  state = ''
  country = ''
  zip = ''
  constructor(
    private userService: UserService,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.userService.getUser().subscribe(response => {
      if (response["status"] == "success") {
        const data = response['data']

        this.firstName = data[0]['firstName']
        this.lastName = data[0]['lastName']
        this.phone = data[0]['phone']
        this.email = data[0]['email']
        this.address = data[0]['address']
        this.city = data[0]['city']
        this.state = data[0]['state']
        this.country = data[0]['country']
        this.zip = data[0]['zip']
      } else {
        this.toastr.warning(response["error"])
      }
    })
  }
  onEdit() {

    this.userService
      .updateBuyer(this.firstName, this.lastName, this.phone, this.email, this.address, this.city, this.state, this.country, this.zip)
      .subscribe(response => {
        console.log(response)
        if (response['status'] == 'success') {
          // this.allBooks = 
          this.toastr.success("Book Edited Successfully")
          this.router.navigate(['home/user/profile'])
        } else {
          alert(response['error'])
        }
      })
  }
  onCan() {
    this.router.navigate(['home/user/profile'])
  }
}
