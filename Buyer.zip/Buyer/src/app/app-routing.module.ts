import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { HomeComponentComponent } from './home-component/home-component.component';

const routes: Routes = [
  // default route
  { path: '', redirectTo: '/home/book/gallery', pathMatch: 'full' },
  {
    path: 'home',
    component: HomeComponentComponent,
    children: [
      { path: 'user', loadChildren: () => import('./user/user.module').then(m => m.UserModule) },
      { path: 'order', loadChildren: () => import('./order/order.module').then(m => m.OrderModule) },
      { path: 'book', loadChildren: () => import('./book/book.module').then(m => m.BookModule) },
   

    ],
    canActivate: [AuthService]

  },
  { path: 'auth', loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
