import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DeleteService {
  
  constructor(
    private httpClient : HttpClient
  ) { }

  deleteAcc(){
    const url="http://localhost:4000/seller/delete"

    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
      };
  
      
     return this.httpClient.delete(url ,httpOptions)
  }




}
