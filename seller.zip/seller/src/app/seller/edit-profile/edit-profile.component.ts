import { SellerService } from './../seller.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  
  
  firstName = ''
  lastName = ''
  phone = ''
  email = ''
  address = ''
  city = ''
  state = ''
  country = ''
  zip = ''
  constructor(
    private sellerService: SellerService,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit( ): void {


    this.sellerService.getSeller().subscribe(response=>{
      if(response["status"]=="success"){
        const data=response['data']
       
        this.firstName =data[0]['firstName']
        this.lastName = data[0]['lastName']
        this.phone = data[0]['phone']
        this.email = data[0]['email']
        this.address = data[0]['address']
        this.city = data[0]['city']
        this.state = data[0]['state']
        this.country = data[0]['country']
        this.zip = data[0]['zip']
      }else{
        this.toastr.warning(response["error"])
      }
    })
  }

  onEdit() {

    console.log('inside edit seller')

    this.sellerService
      .updateSeller(this.firstName, this.lastName, this.phone, this.email, this.address, this.city, this.state, this.country, this.zip)
      .subscribe(response => {
      
        if (response['status'] == 'success') {
          // this.allBooks = 
          this.toastr.success("Profile Edited Successfully")
          this.router.navigate(['mybookstore/seller/profile'])
        } else {
          alert(response['error'])
        }
      })
  }

  onCan() {
    this.router.navigate(['mybookstore/seller/profile'])
  }
}
