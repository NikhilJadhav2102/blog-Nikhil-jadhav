import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SellerService {
  url = 'http://localhost:4000/seller'

  constructor(
    private httpClient: HttpClient
  ) { }


  updateSeller(firstName, lastName, phone, email, address, city, state, country, zip) {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    const body = {

      "firstName": firstName,
      "lastName": lastName,
      "phone": phone,
      "email": email,
      "address": address,
      "city": city,
      "state": state,
      "country": country,
      "zip": zip

    }

    console.log('inside Update seller')

    return this.httpClient.put(this.url + '/profile', body, httpOptions)
  }

  getSeller() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    console.log(sessionStorage['token'])


    return this.httpClient.get(this.url + "/profile", httpOptions)
  }
}
