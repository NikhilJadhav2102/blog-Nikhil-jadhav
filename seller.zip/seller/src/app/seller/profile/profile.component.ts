import { Router } from '@angular/router';
import { SellerService } from './../seller.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  sellers=[]

  constructor(
    private router:Router,
    private sellerService:SellerService
  ) { }

  ngOnInit(): void {
    this.loadProfile()
  }

  loadProfile(){
    this.sellerService.getSeller().subscribe(response=>{
      console.log(response)
      if (response['status'] == 'success') {
        // this.allBooks = 
        console.log(response['data'])
        this.sellers = response['data']

      } else {
        alert(response['error'])
      }
    })
  }


  onEdit(){
    this.router.navigate(["/mybookstore/seller/edit-profile"])
  }


}
