import { HttpClientModule } from '@angular/common/http';
import { SellerService } from './seller.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SellerRoutingModule } from './seller-routing.module';
import { ProfileComponent } from './profile/profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [ProfileComponent, EditProfileComponent],
  imports: [
    CommonModule,
    SellerRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers:[
    SellerService
  ]
})
export class SellerModule { }
