import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  url='http://localhost:4000/order'

  constructor(
    private httpClient:HttpClient
  ) { }

  getOrders() {
    // add the token in the request header
   
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    
    return this.httpClient.get(this.url, httpOptions)
  }

  getTotalOrderCount(){
    const url='http://localhost:4000/order'
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    
    return this.httpClient.get(url, httpOptions)
  }

}
