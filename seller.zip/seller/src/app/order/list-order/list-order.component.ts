import { OrderService } from './../order.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-order',
  templateUrl: './list-order.component.html',
  styleUrls: ['./list-order.component.css']
})
export class ListOrderComponent implements OnInit {
  orders=[]
  Total_Revenue=0
  constructor(
    private orderService:OrderService
  ) { }

  ngOnInit(): void {
    this.GenerateRevenue()
    this.loadOrders()
  }
  loadOrders(){
    this.orderService
      .getOrders()
      .subscribe(response => {
        if (response['status'] == 'success') {
          this.orders = response['data']
          console.log(this.orders)
        } else {
          console.log(response['error'])
        }
      })
  }

  
  GenerateRevenue(){
    this.orderService.getTotalOrderCount().subscribe(response=>{
      if (response['status'] == 'success') {
        
        const data=response['data']
      
        var i

        for(i=0;i < data.length ;i++){
         

          if(data[i]['deliveryStatus']=='delivered'){
            this.Total_Revenue=this.Total_Revenue +  parseFloat(data[i]['totalAmount'])
          }
        }
       
      } 
    })

}
}
