import { BookService } from './book.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookRoutingModule } from './book-routing.module';
import { BookListComponent } from './book-list/book-list.component';
import { BookViewComponent } from './book-view/book-view.component';
import { BookAddComponent } from './book-add/book-add.component';
import { CategoryService } from './category.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BookEditComponent } from './book-edit/book-edit.component';


@NgModule({
  declarations: [BookListComponent, BookViewComponent, BookAddComponent, BookEditComponent],
  imports: [
    CommonModule,
    BookRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers:[
    BookService,
    CategoryService
  ]
})
export class BookModule { }
