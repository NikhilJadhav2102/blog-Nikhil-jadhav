import { CategoryService } from './../category.service';
import { ToastrService } from 'ngx-toastr';
import { BookService } from './../book.service';
import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-book-add',
  templateUrl: './book-add.component.html',
  styleUrls: ['./book-add.component.css']
})
export class BookAddComponent implements OnInit {
  title= ''
  description = ''
  price = 0
  category = 1
  language=''
  author=''
  pages=0
  stock=0
 
  image = undefined

  categories = []


  constructor(
    private modal: NgbActiveModal,
    private bookService:BookService,
    private toastr:ToastrService,
    private categoryService : CategoryService
  ) { }

  ngOnInit(): void {

    this.loadCategories()
  }
  onAdd() {
  
    
    if (this.title.length == 0) {
      this.toastr.warning('please enter title')
    }else if (this.author.length == 0) {
      this.toastr.warning('please enter author')
    }  else if (this.language.length == 0) {
      this.toastr.warning('please enter Language')
    }  else if (this.pages == 0) {
      this.toastr.warning('please enter Pages')
    }  else if (this.price == 0) {
      this.toastr.warning('please enter price')
    } else if (this.description.length == 0) {
      this.toastr.warning('please enter description')
    } else if (this.stock == 0) {
      this.toastr.warning('please enter Stock')
    }
    else if (this.image == undefined) {
      this.toastr.warning('please select an image')
    } else {
      console.log("Inside Add")
      this.bookService
        .addBook(this.title,this.author,this.language,this.pages,this.price, this.description, this.stock, this.category, this.image)
        .subscribe(response => {
          if (response['status'] == 'success') {
            this.modal.dismiss('ok')
          } else {
            this.toastr.error(response['error'])
            alert(response['error'])
          }
        })
    }
  }

  loadCategories() {
    this.categoryService
      .getCategories()
      .subscribe(response => {
        if (response['status'] == 'success') {
          this.categories = response['data']
          console.log(response['data'])
        } else {
          this.toastr.error(response['error'])
        }
      })
  }


  onImageSelected(event) {
    // get the selected file
    this.image = event.target.files[0]
  }

  
  onCancel() {
    this.modal.dismiss('cancel')
  }

}
