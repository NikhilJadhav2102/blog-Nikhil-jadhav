import { ToastrService } from 'ngx-toastr';
import { CategoryService } from './../category.service';
import { BookService } from './../book.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-edit',
  templateUrl: './book-edit.component.html',
  styleUrls: ['./book-edit.component.css']
})
export class BookEditComponent implements OnInit {


  bookId=0
  title= ''
  description = ''
  price = 0
  category =1
  language=''
  author=''
  pages=0
  stock=0
  image = undefined

  categories = []
  product = null



  constructor(
    private router:Router,
    private activatedRoute: ActivatedRoute,
    private bookService:BookService,
    private categoryService:CategoryService,
    private toastr:ToastrService
  ) { }
  //

  ngOnInit(): void {
    const id = this.activatedRoute.snapshot.queryParams['bookId']
    console.log(id)
    this.loadCategories()
    this.bookService
    .getBookDetails(id)
    .subscribe(response => {
      if (response['status'] == 'success') {
        const products = response['data']
        console.log(response['data'])
        if (products.length > 0) {
          
          this.product = products[0]
          this.bookId=this.product["bookId"]
          this.title = this.product['title']
          this.description = this.product['description']
          this.price = this.product['price']
          this.author = this.product['author']
          this.language=this.product['language']
          this.pages=this.product['pages']
          this.stock=this.product['stock']
          this.category = this.product['categoryId']
         
        }
      }
    })

  }

  loadCategories() {
    this.categoryService
      .getCategories()
      .subscribe(response => {
        if (response['status'] == 'success') {
          this.categories = response['data']
          console.log(response['data'])
        } else {
          this.toastr.error(response['error'])
        }
      })
  }
  
  onAdd() {
  
    
    if (this.title.length == 0) {
      this.toastr.warning('please enter title')
    }else if (this.author.length == 0) {
      this.toastr.warning('please enter author')
    }  else if (this.language.length == 0) {
      this.toastr.warning('please enter Language')
    }  else if (this.pages == 0) {
      this.toastr.warning('please enter Pages')
    }  else if (this.price == 0) {
      this.toastr.warning('please enter price')
    } else if (this.description.length == 0) {
      this.toastr.warning('please enter description')
    } else if (this.stock == 0) {
      this.toastr.warning('please enter Stock')
    }
    else {
      console.log("Inside Add")
      this.bookService
        .updateBook(this.bookId,this.title,this.author,this.language,this.pages,this.price, this.description, this.stock, this.category)
        .subscribe(response => {
          if (response['status'] == 'success') {
            this.toastr.success("Book Edited Successfully")
            this.router.navigate(['mybookstore/book/book-list'])
          } else {
            this.toastr.error(response['error'])
            this.toastr.warning(response['error'])
          }
        })
    }
  }


  onCancel(){
    this.router.navigate(['mybookstore/book/book-list'])
  }
}
