import { ToastrService } from 'ngx-toastr';
import { BookService } from './../book.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BookAddComponent } from '../book-add/book-add.component';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  products = []

  constructor(
    private toaster:ToastrService,
    private modalService: NgbModal,
    private bookService:BookService,
    private router:Router
  ) { }

  ngOnInit(): void {
    this.loadProducts()
  }

  loadProducts() {
    this.bookService
      .getBooks()
      .subscribe(response => {
        if (response['status'] == 'success') {
          this.products = response['data']
         
        } else {
          console.log(response['error'])
        }
      })
  }

  onAdd() {
    const modalRef = this.modalService.open(BookAddComponent, {size: 'lg'})
    modalRef.result.finally(() => {
      this.loadProducts()
    })
  }

  Delete(product){
   
    this.bookService
    .deleteBooks(product)
    .subscribe(response => {
      if (response['status'] == 'success') {
        this.loadProducts()
        this.toaster.success("Book Deleted")
      } else {
        
        this.toaster.warning(response['error'])
      }
    })

  }

  onEdit(product) {
    this.router.navigate(['mybookstore/book/book-edit'], {queryParams: {bookId: product['bookId']}})
  }




}
