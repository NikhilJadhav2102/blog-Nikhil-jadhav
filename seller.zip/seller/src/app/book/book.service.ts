import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  url='http://localhost:4000/book'
  constructor(
    private httpClient:HttpClient
  ) { }

  getBookDetails(bookId){
    
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + `/${bookId}`, httpOptions)
  }

  updateBook(bookId,title,author,language,pages,price, description, stock, category){
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    const body = {
      
        "title":title,
        "author":author,
        "pages":pages,
        "language":language,
        "description":description,
        "categoryId":category,
        "price":price,
        "stock":stock
    
    }
   

    return this.httpClient.put(this.url + `/${bookId}`,body, httpOptions)
  }

  getBooks(){
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url, httpOptions)
  }
  
  addBook(title,author,language,pages,price, description, stock, category, image) {
    // use formdata to collect the value with a file as one of the parameters
    
    const body = new FormData()
    body.append("title", title)
    body.append("description", description)
    body.append("price", price)
    body.append("author", author)
    body.append("language", language)
    body.append("pages", pages)
    body.append("stock", stock)
    body.append("categoryId", '' + category)
    body.append("photo", image)
    
    console.log("Inside add Book")
    // send the token along with the request
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    }
   
    return this.httpClient.post(this.url, body, httpOptions)
  }


  deleteBooks(product){
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
  
    return this.httpClient.delete(this.url + `/${product.bookId}`, httpOptions)
  }

}
