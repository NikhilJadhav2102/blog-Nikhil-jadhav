import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(
    private httpClient: HttpClient
  ) { }

  getBookCount(){
 
   const url='http://localhost:4000/book/count'
   const httpOptions = {
    headers: new HttpHeaders({
      token: sessionStorage['token']
    })
    };

   return this.httpClient.get(url,httpOptions)
  }

  getActiveBookCount(){
    console.log('Inside getbookcount')
    const url='http://localhost:4000/book/active_count'
    const httpOptions = {
     headers: new HttpHeaders({
       token: sessionStorage['token']
     })
     };
 

    return this.httpClient.get(url,httpOptions)
  }

  
  getInActiveBookCount(){

    const url='http://localhost:4000/book/inactive_count'
    const httpOptions = {
     headers: new HttpHeaders({
       token: sessionStorage['token']
     })
     };
 
     
    return this.httpClient.get(url,httpOptions)
  }

  getOrders() {
    // add the token in the request header
    const url='http://localhost:4000/order/count'
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    
    return this.httpClient.get(url, httpOptions)
  }

  getTotalOrderCount(){
    const url='http://localhost:4000/order'
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    
    return this.httpClient.get(url, httpOptions)
  }

  getDeliveredOrderCount(){
    const url='http://localhost:4000/order/delivered_order'
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(url, httpOptions)
  }
}
