import { ToastrService } from 'ngx-toastr';
import { DashboardService } from './../dashboard.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  Total_Revenue=0
  book_count=0
  Active_book_count=0
  In_Active_book_count=0
  Active_orders=0
  Total_Orders=0
  Delivered_order_count=0
  constructor(
    private dashboardservice: DashboardService,
    private toastr:ToastrService
  ) { }

  ngOnInit(): void {
    this.bookcount()
    this.activebookcount()
    this.inctivebookcount()
    this.activeOrder()
    this.TotalOrderCount()
    this.DeliveredOrderCount()
    this.GenerateRevenue()
  }

  bookcount(){
    
    this.dashboardservice.getBookCount().subscribe(response=>{
      if (response['status'] == 'success') {
        this.book_count=response['data']
      } else {
        this.toastr.error(response['error'])
       
      }
    })
  }

  activebookcount(){
   
    this.dashboardservice.getActiveBookCount().subscribe(response=>{
      if (response['status'] == 'success') {
        this.Active_book_count=response['data']
      } else {
        this.toastr.error(response['error'])
       
      }
    })
  }
  
  TotalOrderCount(){
   
    this.dashboardservice.getTotalOrderCount().subscribe(response=>{
      if (response['status'] == 'success') {
        
        const data=response['data']
        
        this.Total_Orders=data.length
      } else {
        this.toastr.error(response['error'])
       
      }
    })
  }
  
  
  DeliveredOrderCount(){
   
    this.dashboardservice.getDeliveredOrderCount().subscribe(response=>{
      if (response['status'] == 'success') {
        
        const data=response['data']
        
        this.Delivered_order_count=data.length
      } else {
        this.toastr.error(response['error'])
       
      }
    })
  }
  
    GenerateRevenue(){
      this.dashboardservice.getTotalOrderCount().subscribe(response=>{
        if (response['status'] == 'success') {
          
          const data=response['data']
        
          var i

          for(i=0;i < data.length ;i++){
           

            if(data[i]['deliveryStatus']=='delivered'){
              this.Total_Revenue=this.Total_Revenue +  parseFloat(data[i]['totalAmount'])
            }
          }
          this.Total_Orders=data.length
        } else {
          this.toastr.error(response['error'])
         
        }
      })

  }

  activeOrder(){
    this.dashboardservice.getOrders().subscribe(response=>{
      if (response['status'] == 'success') {
        const data=response['data']
        this.Active_orders=data.length
        
      } else {
        this.toastr.error(response['error'])
       
      }
    })
  }

  inctivebookcount(){

    this.dashboardservice.getInActiveBookCount().subscribe(response=>{
      if (response['status'] == 'success') {
        this.In_Active_book_count=response['data']
      } else {
        this.toastr.error(response['error'])
       
      }
    })
  }
}


