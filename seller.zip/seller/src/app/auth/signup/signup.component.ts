import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  firstName = ''
  lastName = ''
  email = ''
  phone = ''
  password = ''
  confirmPassword = ''


  constructor(
    private toaster: ToastrService,
    private router: Router,
    private service: AuthService,
  ) { }

  ngOnInit(): void {
  }

  onSignup(){
    if (this.firstName.length == 0) {
      this.toaster.warning('please enter first name')
    } else if (this.lastName.length == 0) {
      this.toaster.warning('please enter last name')
    } else if (this.email.length == 0) {
      this.toaster.warning('please enter email ')
    } else if (this.phone.length == 0) {
      this.toaster.warning('please enter phone number')
    } else if (this.password.length < 8 ) {
        this.toaster.warning('Use 8 characters or more for your password')
    } else if (this.password.length == 0) {
      this.toaster.warning('please enter password')
    } else if (this.confirmPassword.length == 0) {
      this.toaster.warning('please confirm password')
    } else if (this.password != this.confirmPassword) {
      this.toaster.warning('passwords did not match. Try again.')
    } else {
      this.service
        .signup(this.firstName, this.lastName, this.phone, this.email, this.password)
        .subscribe(response => {
          if (response['status'] == 'success') {
            this.toaster.success('succesfully signed up new account')
            this.router.navigate(['/auth/login'])
          } else {
            this.toaster.error(response['error'])
          }
        })
    }
    
  }

}
