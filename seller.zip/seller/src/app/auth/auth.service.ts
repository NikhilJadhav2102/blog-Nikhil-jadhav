import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate {
url='http://localhost:4000/seller'
  constructor(
    private router:Router,
    private httpclient:HttpClient
  ) { }

 

  login(email:string,password:string){
    const body={
      email:email,
      password:password
    }
    return this.httpclient.post(this.url + '/signin',body)
  }
  signup(firstName:string, lastName:string, phone: string, email: string, password: string) {
    const body = {
      firstname: firstName,
      lastname: lastName,
      phone: phone,
      email: email,
      password: password
    }
    console.log(firstName)
    console.log(lastName)
    return this.httpclient.post(this.url + "/signup", body)
  }




  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (sessionStorage['token']) {
      // user is already logged in
      // launch the component
      return true
    }

    // force user to login
    this.router.navigate(['/auth/login'])

    // user has not logged in yet
    // stop launching the component
    return false 
  }


}
