import { OrderModule } from './order/order.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { AboutModule } from './about/about.module';
import { AuthService } from './auth/auth.service';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/mybookstore/home/about', pathMatch: 'full' },
  {path:'mybookstore',component:HomeComponent,

  children: [

      { path: 'book', loadChildren: () => import('./book/book.module').then(m => m.BookModule) },
      { path: 'home', loadChildren: () => import('./about/about.module').then(m => m.AboutModule) },
      { path: 'seller', loadChildren: () => import('./seller/seller.module').then(m => m.SellerModule) },
      { path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule) },
      { path: 'order', loadChildren: () => import('./order/order.module').then(m => m.OrderModule) },
    ],
  canActivate: [AuthService]},
  { path: 'auth', loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
