import { DeleteService } from './../delete.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(
    private router : Router,
    private toaster:ToastrService,
    private deleteService: DeleteService
  ) { }

  ngOnInit(): void {
  }
  onLogout(){
    sessionStorage.removeItem('token')
    sessionStorage.removeItem('firstName')
    sessionStorage.removeItem('lastName')
    this.toaster.success('Login Successfull')

    this.router.navigate(['auth/login'])
  }


  onDel(){
    console.log('Inside onDel')
    this.deleteService.deleteAcc().subscribe(response=>{
      if (response['status'] == 'success') {
        sessionStorage.removeItem('token')
        sessionStorage.removeItem('firstName')
        sessionStorage.removeItem('lastName')
        this.toaster.success('Account Deleted Successfully..')

        this.router.navigate(['auth/login'])
      } else {
        this.toaster.error("Server-Down please try again...")
       
      }
    })
  }
}
